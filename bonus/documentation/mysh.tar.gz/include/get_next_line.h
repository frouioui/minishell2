/*
** EPITECH PROJECT, 2018
** minishell2
** File description:
** Contains the read size of the get_next_line function
*/

#ifndef GET_NEXT_LINE_H
#define GET_NEXT_LINE_H

#define READ_SIZE 16

#endif /* end of include guard: GET_NEXT_LINE_H */
